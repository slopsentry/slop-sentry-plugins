# Slop Sentry

Slop Sentry checks a draft for thin claims, try-hard language, and AI-sounding patterns, then returns a cleaned version. Connect the remote server and approve access in the browser with your Slop Sentry account.

Version `1.12.0`. Remote MCP endpoint: `https://mcp.slopsentry.ai`.

## Setup

1. Install this plugin in Antigravity (`agy plugin install ./slop-sentry` or from the Marketplace).
2. Sign up or sign in at https://slopsentry.ai if you do not already have an account.
3. When the MCP server connects, approve browser sign-in with your Slop Sentry account.
4. Verify with `slop_sentry_whoami`.

No API keys ship in this package. Account keys are only for CLI or CI clients that still need a pasted account token.

## Included

- Remote MCP server in `mcp_config.json` pointing at `https://mcp.slopsentry.ai`.
- `skills/slop-sentry`: draft checks, rewrites, and result polling.
- `skills/install-slop-sentry`: connect Slop Sentry across supported AI clients.

## Privacy

Privacy policy: https://slopsentry.ai/privacy
Support: support@slopsentry.ai
